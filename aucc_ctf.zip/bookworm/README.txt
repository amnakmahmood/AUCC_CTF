

## Description

This was the only file on an old harddrive. There was a sticky note on it too with the following message:

(1, 3, 2) (9, 6, 2) (17, 1, 2) (17, 1, 3) (12, 1, 1) (85, 5, 1) (7, 10, 1) (40, 1, 1)
(19, 4, 1) (63, 5, 4) (63, 7, 3) (89, 2, 1) (11, 8, 4) (31, 5, 1) (94, 1, 5) (60, 9, 2) (19, 5, 8) 


## Hint

What if these numbers each pointed to a letter? 20


```

## Notes

It goes (line, word, letter).

If you finish this flag, try to script it in python! 
(In case you don't have Python locally installed, https://www.programiz.com/python-programming/online-compiler/)

