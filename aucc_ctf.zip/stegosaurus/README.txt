

## Description
I like dinosaurs.

## Required Files
dino.png

## Hint
My favorite dinosaurs came from this time period.
Learn about strings!
https://www.fileformat.info/tool/strings.htm

